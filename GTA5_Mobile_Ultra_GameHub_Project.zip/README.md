# GTA 5 MOBILE ULTRA — Android proje taslağı

Bu bir **Android kaynak proje taslağıdır**, hazır APK değildir. Android Studio + Android SDK ile derlenebilir.

## Derleme
1. Android Studio'da bu klasörü aç.
2. Gradle senkronizasyonunu tamamla (Android Gradle Plugin 8.6.1, SDK 35 gerekir).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Gerçekçi işlev sınırları
- Uygulama çevrimdışı çalışan bir başlatıcı/ayar rehberidir.
- Yüklü uygulamalar arasında adında GTA / Grand Theft Auto geçen oyunu bulup açmayı dener.
- Performans profilleri öneri gösterir; portun grafik/FPS ayarlarını uzaktan değiştirmez.
- Android normal uygulamalara başka bir oyunun CPU/GPU frekansını, FPS kilidini veya özel belleğini zorla yönetme izni vermez.
- Mod kurma işlevi eklenmemiştir; her portun mod sistemi farklıdır ve doğrulanmadan oyun dosyalarını değiştirmek çökme/bozulma riski taşır.

## Paket
Application ID: `com.gta5mobile.ultra`

## APK'yi yalnızca telefonla bulutta derleme
Projede `.github/workflows/android.yml` iş akışı vardır. ZIP'i GitHub'da yeni bir depoya yükleyip `main` dalına gönderdiğinde Actions otomatik olarak APK derlemeyi dener. GitHub deposunda Actions etkin olmalı. İşlem bitince Actions > ilgili çalışma > Artifacts bölümünden `GTA5-MOBILE-ULTRA-debug-apk` dosyasını indir.

## GameHub Lite uyumluluğu
Ana ekranda GameHub Lite'ı açma düğmesi bulunur. Bu yalnızca GameHub uygulamasını başlatır; GameHub'ın oyun profillerini veya FPS ayarlarını değiştirmez. GTA portunu da kendi başlatma düğmesiyle açmayı dener. Android uygulamaları başka bir uygulamanın özel ayarlarını izinsiz değiştiremez.
