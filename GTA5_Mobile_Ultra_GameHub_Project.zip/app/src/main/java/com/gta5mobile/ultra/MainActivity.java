package com.gta5mobile.ultra;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int red = Color.rgb(255,48,48), white = Color.WHITE, muted = Color.rgb(180,180,180);
    LinearLayout root;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,9,9));
        getWindow().setNavigationBarColor(Color.rgb(9,9,9));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 26, 22, 22);
        root.setBackgroundColor(Color.rgb(12,12,14));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = new TextView(this);
        brand.setText("GTA 5");
        brand.setTextColor(red); brand.setTextSize(34); brand.setTypeface(null, Typeface.BOLD);
        root.addView(brand);
        TextView sub = new TextView(this);
        sub.setText("MOBILE ULTRA  •  OFFLINE LAUNCHER");
        sub.setTextColor(white); sub.setTextSize(14);
        root.addView(sub);
        addSpace(24);

        Button launch = button("GTA 5'İ BAŞLAT");
        root.addView(launch);
        launch.setOnClickListener(v -> launchGame());

        Button gamehub = button("GAMEHUB LITE'I AÇ");
        root.addView(gamehub);
        gamehub.setOnClickListener(v -> launchNamedApp("gamehub"));

        addSpace(18);
        heading("PERFORMANS PROFİLİ");
        TextView note = text("POCO X6 Pro için başlangıç önerisi. Bu seçimler oyun motorunun ayarlarını kendiliğinden değiştirmez; mevcut oyun ayarlarından elle uygulanmalıdır.");
        root.addView(note);
        addSpace(10);
        root.addView(profile("AKICI", "Graphics: LOW  •  Texture: MEDIUM  •  FPS hedefi: 60"));
        root.addView(profile("DAHA SERİN", "Graphics: LOW  •  Texture: LOW  •  FPS hedefi: 30 veya 40"));
        root.addView(profile("GÖRÜNTÜ KALİTESİ", "Graphics: MEDIUM  •  Texture: MEDIUM  •  Isınmayı takip et"));
        addSpace(18);
        heading("MOD DOSYALARI");
        root.addView(text("Bu ilk sürüm modları oyuna kurmaz. Bilinmeyen APK/mod dosyalarını yüklemeden önce kaynağını doğrula; orijinal oyun dosyalarının yedeğini sakla."));
        addSpace(18);
        heading("DURUM");
        status = text("Çevrimdışı arayüz hazır. Oyun paketi aranıyor…");
        root.addView(status);
        addSpace(12);
        Button detect = button("OYUNU TEKRAR BUL");
        root.addView(detect);
        detect.setOnClickListener(v -> launchGame());
        addSpace(22);
        TextView disclaimer = text("Not: Bu uygulama FPS kilidini zorla değiştirmez, CPU/GPU hız aşırtması yapmaz ve oyunun iç dosyalarına müdahale etmez. Gerçek FPS; port, sıcaklık ve oyun sahnesine bağlıdır.");
        disclaimer.setTextSize(12);
        root.addView(disclaimer);
    }

    void launchNamedApp(String keyword) {
        PackageManager pm = getPackageManager();
        for (android.content.pm.ApplicationInfo app : pm.getInstalledApplications(0)) {
            String label = pm.getApplicationLabel(app).toString().toLowerCase();
            if (label.contains(keyword) && !app.packageName.equals(getPackageName())) {
                Intent i = pm.getLaunchIntentForPackage(app.packageName);
                if (i != null) { startActivity(i); status.setText("Açıldı: " + pm.getApplicationLabel(app)); return; }
            }
        }
        status.setText("GameHub Lite bulunamadı. Yüklüyse ana ekrandan açabilirsin.");
        Toast.makeText(this, "GameHub Lite bulunamadı", Toast.LENGTH_LONG).show();
    }

    void launchGame() {
        PackageManager pm = getPackageManager();
        for (android.content.pm.ApplicationInfo app : pm.getInstalledApplications(0)) {
            String label = pm.getApplicationLabel(app).toString().toLowerCase();
            if ((label.contains("gta") || label.contains("grand theft auto")) && !app.packageName.equals(getPackageName())) {
                Intent i = pm.getLaunchIntentForPackage(app.packageName);
                if (i != null) { startActivity(i); status.setText("Oyun açıldı: " + pm.getApplicationLabel(app)); return; }
            }
        }
        status.setText("Yüklü GTA oyunu otomatik bulunamadı. Oyunu telefonundaki kendi simgesinden açabilirsin.");
        Toast.makeText(this, "GTA oyunu bulunamadı", Toast.LENGTH_LONG).show();
    }

    void heading(String s) {
        TextView t = text(s); t.setTextColor(red); t.setTextSize(16); t.setTypeface(null, Typeface.BOLD);
        root.addView(t); addSpace(8);
    }
    TextView text(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(white); t.setTextSize(14);
        t.setPadding(0,5,0,5); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(white);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
        return b;
    }
    View profile(String title, String desc) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14,10,14,10); box.setBackgroundColor(Color.rgb(29,29,33));
        TextView a = text(title); a.setTextColor(red); a.setTypeface(null,Typeface.BOLD);
        box.addView(a); box.addView(text(desc)); addSpace(7);
        return box;
    }
    void addSpace(int h) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1,h)); }
}
